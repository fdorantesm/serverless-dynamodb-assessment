export enum TransferType {
  'abono' = 'abono',
  'cargo' = 'cargo',
}
