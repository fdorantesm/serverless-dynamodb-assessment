export enum OriginAccountType {
  'cuenta_corriente' = 'cuenta_corriente',
}
