export enum OriginAccountType {
  'cuenta_corriente' = 'cuenta_corriente',
  'cuenta_vista' = 'cuenta_vista',
}
