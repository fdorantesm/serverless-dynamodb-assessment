export interface BaseProps {
  id: string;
}
