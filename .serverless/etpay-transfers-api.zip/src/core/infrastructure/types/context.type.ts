import type { DynamoRepository } from '@/core/infrastructure/classes/dynano-repository';
import type { Repositories } from '@/core/infrastructure/enums/repositories.enum';
import type { S3Service } from '@/shared/infrastructure/storage/s3.service';
import { Context as LambdaContext } from 'aws-lambda';

export type Context = LambdaContext & {
  repositories: {
    [key in Repositories]: DynamoRepository;
  };
  services: {
    s3Service: S3Service;
  };
};
