export enum Repositories {
  TransferRepository = 'TransferRepository',
}
